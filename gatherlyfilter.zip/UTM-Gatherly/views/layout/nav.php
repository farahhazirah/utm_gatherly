<div class="topnav shadow-lg" id="navbar">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">

                    <li class="nav-item dropdown">

                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>