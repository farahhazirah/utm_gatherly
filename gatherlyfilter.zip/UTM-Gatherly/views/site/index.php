<h1><?php echo $title; ?></h1>
<p>Welcome to the home page!</p>